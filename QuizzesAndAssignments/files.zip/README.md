## Getting and Cleaning Data Week-3 Course Project

### The run_analysis.R performs the following actions on the data 
###-------------------------------------------------------------------------------------------------------------------------
* Download and unzip files if they are not there already
* Bind  the train and test datasets
* Merge the the datasets into one and apply column names
* Factorize Activity to activity labels
* Appropriately label with descriptive names
* Create second independent tidy data set with the average of each variable for each activity and each subject.